define(
[    
    'jquery',
    'mage/mage'
],
    function ($) {
        'use strict';
        return {
            /**
             * Validate something
             *
             * @returns {boolean}
             */
            validate: function() {
                var form = $('form[data-role=checkout-custompayment]');
                form.validation();
                return $(form).validation() && $(form).validation('isValid');
            }
        }
    }
);
