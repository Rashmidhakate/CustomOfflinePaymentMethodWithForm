define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/additional-validators',
        'Custom_CustomPaymentMethod/js/model/custompayment-validator'
    ],
    function (Component, additionalValidators, custompaymentValidator) {
        'use strict';
        additionalValidators.registerValidator(custompaymentValidator);
        return Component.extend({});
    }
);
