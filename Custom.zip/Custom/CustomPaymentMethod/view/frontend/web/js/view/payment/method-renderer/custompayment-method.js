/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/* @api */
define([
    'ko',
    'Magento_Checkout/js/view/payment/default',
    'jquery'
], function (ko, Component,$) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Custom_CustomPaymentMethod/payment/custompayment'
        },

        getData: function() {
            return {
                'method': this.item.method,
                'additional_data': {
                    'company_name': $('#custompayment_company_name').val(),
                    'company_email': $('#custompayment_company_email').val(),
                    'bank_account_number': $('#custompayment_bank_account_number').val(),
                    'swift_code': $('#custompayment_swift_code').val()
                }
            };
        },
        /**
         * Get value of instruction field.
         * @returns {String}
         */
        getInstructions: function () {
            return window.checkoutConfig.payment.instructions[this.item.method];
        },
    });
});
