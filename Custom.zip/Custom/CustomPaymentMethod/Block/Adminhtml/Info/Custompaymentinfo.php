<?php
namespace Custom\CustomPaymentMethod\Block\Adminhtml\Info;

use Magento\Framework\Registry;

class Custompaymentinfo extends \Magento\Sales\Block\Adminhtml\Order\View
{

	public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Sales\Model\Config $salesConfig,
        \Magento\Sales\Helper\Reorder $reorderHelper,
        \Magento\Quote\Model\QuoteRepository $quoteRepository,
        array $data = []
    ) {
        $this->_reorderHelper = $reorderHelper;
        $this->_coreRegistry = $registry;
        $this->_salesConfig = $salesConfig;
        $this->quoteRepository = $quoteRepository;
        parent::__construct($context,$registry,$salesConfig,$reorderHelper,$data);
    }

    public function getQuote(){
    	return $this->quoteRepository;
    }

}