<?php
namespace Custom\CustomPaymentMethod\Setup;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
class InstallSchema implements InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();   
        $setup->getConnection()->addColumn(
            $setup->getTable('quote_payment'),
            'company_name',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'nullable' => true  ,
                'length' => 255,
                'comment' => 'Company Name'
            ]
        );
        $setup->getConnection()->addColumn(
            $setup->getTable('quote_payment'),
            'company_email',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'nullable' => true  ,
                'length' => 255,
                'comment' => 'Company Email'
            ]
        );
        $setup->getConnection()->addColumn(
            $setup->getTable('quote_payment'),
            'bank_account_number',
            [
                'type' =>\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'nullable' => true  ,
                'length' => 255,
                'comment' => 'Bank Account Number'
            ]
        );
        $setup->getConnection()->addColumn(
            $setup->getTable('quote_payment'),
            'swift_code',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'nullable' => true  ,
                'length' => 255,
                'comment' => 'Swift Code'
            ]
        );
        $setup->getConnection()->addColumn(
            $setup->getTable('sales_order_payment'),
            'company_name',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'nullable' => true  ,
                'length' => 255,
                'comment' => 'Company Name'
            ]
        );
        $setup->getConnection()->addColumn(
            $setup->getTable('sales_order_payment'),
            'company_email',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'nullable' => true  ,
                'length' => 255,
                'comment' => 'Company Email'
            ]
        );
        $setup->getConnection()->addColumn(
            $setup->getTable('sales_order_payment'),
            'bank_account_number',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'nullable' => true  ,
                'length' => 255,
                'comment' => 'Bank Account Number'
            ]
        );
        $setup->getConnection()->addColumn(
            $setup->getTable('sales_order_payment'),
            'swift_code',
            [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                'nullable' => true  ,
                'length' => 255,
                'comment' => 'Swift Code'
            ]
        );
        $setup->endSetup();
  }
}