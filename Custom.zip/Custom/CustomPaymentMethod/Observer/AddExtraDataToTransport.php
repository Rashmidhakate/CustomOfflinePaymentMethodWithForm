<?php

namespace Custom\CustomPaymentMethod\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Model\Order;

class AddExtraDataToTransport implements ObserverInterface
{  

	public function __construct(
        \Magento\Quote\Model\QuoteRepository $quoteRepository
    ) {
        $this->quoteRepository = $quoteRepository;
     }
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
		$transport = $observer->getEvent()->getTransport();
		$order = $transport->getOrder();
		$transport['comapany_name'] = $this->getQuote($order)->getCompanyName();
		$transport['comapany_email'] = $this->getQuote($order)->getCompanyEmail();
		$transport['bank_account_number'] = $this->getQuote($order)->getBankAccountNumber();
		$transport['swift_code'] = $this->getQuote($order)->getSwiftCode();
    }

    public function getQuote(Order $order){
        $quote = $this->quoteRepository->get($order->getQuoteId());
        $paymentQuote = $quote->getPayment();
        return $paymentQuote;
    }
}