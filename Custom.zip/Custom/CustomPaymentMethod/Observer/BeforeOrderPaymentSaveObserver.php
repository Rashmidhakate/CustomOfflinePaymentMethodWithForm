<?php
namespace Custom\CustomPaymentMethod\Observer;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Custom\CustomPaymentMethod\Model\Custompayment;

class BeforeOrderPaymentSaveObserver implements ObserverInterface {
    protected $_inputParamsResolver;
    protected $_quoteRepository;
    protected $logger;
    protected $_state;
    public function __construct(
        \Magento\Webapi\Controller\Rest\InputParamsResolver $inputParamsResolver, 
        \Magento\Quote\Model\QuoteRepository $quoteRepository, 
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\State $state
        ) {
        $this->_inputParamsResolver = $inputParamsResolver;
        $this->_quoteRepository = $quoteRepository;
        $this->logger = $logger;
        $this->_state = $state;
    }
    public function execute(EventObserver $observer) {

        $payment = $observer->getEvent()->getPayment();
        $instructionMethods = [
            Custompayment::PAYMENT_METHOD_CUSTOM_INVOICE_CODE
        ];
        if (in_array($payment->getMethod(), $instructionMethods)) {
            $inputParams = $this->_inputParamsResolver->resolve();
            foreach ($inputParams as $inputParam) {
                if ($inputParam instanceof \Magento\Quote\Model\Quote\Payment) {
                    $paymentData = $inputParam->getData('additional_data');
                    $order = $payment->getOrder();
                    $quote = $this->_quoteRepository->get($order->getQuoteId());
                    $paymentQuote = $quote->getPayment();
                    $method = $paymentQuote->getMethodInstance()->getCode();

                    if(isset($paymentData['company_name'])){
                        $paymentQuote->setData('company_name', $paymentData['company_name']);
                        $paymentQuote->setData('company_email', $paymentData['company_email']);
                        $paymentQuote->setData('bank_account_number', $paymentData['bank_account_number']);
                        $paymentQuote->setData('swift_code', $paymentData['swift_code']);
                        $payment->setAdditionalInformation(
                            'instructions',
                            $payment->getMethodInstance()->getInstructions()
                        );
                        $payment->setCompanyName(
                            $paymentData['company_name']
                        );
                        $payment->setCompanyEmail(
                            $paymentData['company_email']
                        );
                        $payment->setBankAccountNumber(
                            $paymentData['bank_account_number']
                        );
                        $payment->setSwiftCode(
                            $paymentData['swift_code']
                        );                    
                    }
                }
            }
        } 
    }
}